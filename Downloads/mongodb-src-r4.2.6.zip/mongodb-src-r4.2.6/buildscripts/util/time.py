"""Utilities for working with time."""


def ns2sec(ns):
    """Convert ns to seconds."""
    return ns / (10**9)
