"""Resmokeconfig module."""

from .suites import NAMED_SUITES
from .loggers import NAMED_LOGGERS
